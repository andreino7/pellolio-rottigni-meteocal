/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.meteocal.schedule;

/**
 *
 * @author Filippo
 */
public class Visibility {
    public static final String Private="PRIVATE";
    public static final String Public="PUBLIC";

}
