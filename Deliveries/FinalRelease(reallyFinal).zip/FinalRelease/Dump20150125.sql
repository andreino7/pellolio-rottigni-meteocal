CREATE DATABASE  IF NOT EXISTS `MeteoCalDB` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `MeteoCalDB`;
-- MySQL dump 10.13  Distrib 5.6.19, for osx10.7 (i386)
--
-- Host: 127.0.0.1    Database: MeteoCalDB
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AdminNotification`
--

DROP TABLE IF EXISTS `AdminNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AdminNotification` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `State` varchar(45) NOT NULL DEFAULT 'UNREAD',
  `About` int(11) NOT NULL,
  `Receiver` varchar(50) NOT NULL,
  `CreationDate` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Rec_idx` (`Receiver`),
  KEY `Ev_idx` (`About`),
  CONSTRAINT `AdminEv` FOREIGN KEY (`About`) REFERENCES `Event` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AdminRec` FOREIGN KEY (`Receiver`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AdminNotification`
--

LOCK TABLES `AdminNotification` WRITE;
/*!40000 ALTER TABLE `AdminNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `AdminNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Calendar`
--

DROP TABLE IF EXISTS `Calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Calendar` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(45) NOT NULL,
  `Visibility` varchar(45) NOT NULL,
  `Owner` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Owner_idx` (`Owner`),
  CONSTRAINT `CalOwner` FOREIGN KEY (`Owner`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Calendar`
--

LOCK TABLES `Calendar` WRITE;
/*!40000 ALTER TABLE `Calendar` DISABLE KEYS */;
INSERT INTO `Calendar` VALUES (24,'firstCalendar','PRIVATE','first@yopmail.com');
/*!40000 ALTER TABLE `Calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChangedEventNotification`
--

DROP TABLE IF EXISTS `ChangedEventNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChangedEventNotification` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `State` varchar(45) NOT NULL DEFAULT 'UNREAD',
  `About` int(11) NOT NULL,
  `Receiver` varchar(50) NOT NULL,
  `CreationDate` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Rec_idx` (`Receiver`),
  KEY `Ev_idx` (`About`),
  CONSTRAINT `Eve` FOREIGN KEY (`About`) REFERENCES `Event` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Rec` FOREIGN KEY (`Receiver`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChangedEventNotification`
--

LOCK TABLES `ChangedEventNotification` WRITE;
/*!40000 ALTER TABLE `ChangedEventNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChangedEventNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Event`
--

DROP TABLE IF EXISTS `Event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Event` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(45) NOT NULL,
  `Visibility` varchar(45) NOT NULL,
  `Date` datetime NOT NULL,
  `EndDate` datetime NOT NULL,
  `Location` varchar(70) NOT NULL,
  `Type` int(11) DEFAULT '1',
  `Weather` varchar(45) DEFAULT NULL,
  `EventOwner` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Type_idx` (`Type`),
  KEY `EventOwner_idx` (`EventOwner`),
  CONSTRAINT `EventOwner` FOREIGN KEY (`EventOwner`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Type` FOREIGN KEY (`Type`) REFERENCES `EventType` (`ID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Event`
--

LOCK TABLES `Event` WRITE;
/*!40000 ALTER TABLE `Event` DISABLE KEYS */;
INSERT INTO `Event` VALUES (85,'firstEvent','PRIVATE','2015-01-28 23:00:00','2015-01-28 23:00:00','Milano,IT',21,'CLEAR','first@yopmail.com'),(87,'secondEventPublic','PRIVATE','2015-01-30 23:00:00','2015-01-30 23:00:00','Roma,IT',22,'RAIN','first@yopmail.com');
/*!40000 ALTER TABLE `Event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EventCalendar`
--

DROP TABLE IF EXISTS `EventCalendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EventCalendar` (
  `Calendar` int(11) NOT NULL,
  `Event` int(11) NOT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`),
  KEY `Cal_idx` (`Calendar`),
  KEY `Ev_idx` (`Event`),
  CONSTRAINT `Cal` FOREIGN KEY (`Calendar`) REFERENCES `Calendar` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Ev` FOREIGN KEY (`Event`) REFERENCES `Event` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EventCalendar`
--

LOCK TABLES `EventCalendar` WRITE;
/*!40000 ALTER TABLE `EventCalendar` DISABLE KEYS */;
INSERT INTO `EventCalendar` VALUES (24,85,113),(24,87,115);
/*!40000 ALTER TABLE `EventCalendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EventType`
--

DROP TABLE IF EXISTS `EventType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EventType` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(45) NOT NULL,
  `Sun` bit(1) NOT NULL,
  `Rain` bit(1) NOT NULL,
  `Snow` bit(1) NOT NULL,
  `Cloud` bit(1) NOT NULL,
  `Personalized` bit(1) NOT NULL,
  `Owner` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Owner_idx` (`Owner`),
  CONSTRAINT `Owner` FOREIGN KEY (`Owner`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EventType`
--

LOCK TABLES `EventType` WRITE;
/*!40000 ALTER TABLE `EventType` DISABLE KEYS */;
INSERT INTO `EventType` VALUES (21,'Indoor','','','','','\0',NULL),(22,'Outdoor','','\0','\0','','\0',NULL);
/*!40000 ALTER TABLE `EventType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InviteNotification`
--

DROP TABLE IF EXISTS `InviteNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `InviteNotification` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `State` varchar(45) NOT NULL DEFAULT 'UNREAD',
  `About` int(11) NOT NULL,
  `Receiver` varchar(50) NOT NULL,
  `Sender` varchar(50) NOT NULL,
  `CreationDate` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `InviteRec_idx` (`Receiver`),
  KEY `InviteSender_idx` (`Sender`),
  KEY `InviteEv_idx` (`About`),
  CONSTRAINT `InviteEv` FOREIGN KEY (`About`) REFERENCES `Event` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `InviteRec` FOREIGN KEY (`Receiver`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `InviteSender` FOREIGN KEY (`Sender`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InviteNotification`
--

LOCK TABLES `InviteNotification` WRITE;
/*!40000 ALTER TABLE `InviteNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `InviteNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResponseNotification`
--

DROP TABLE IF EXISTS `ResponseNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResponseNotification` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `State` varchar(45) NOT NULL DEFAULT 'UNREAD',
  `About` int(11) NOT NULL,
  `Refers` int(11) NOT NULL,
  `Receiver` varchar(50) NOT NULL,
  `Sender` varchar(50) NOT NULL,
  `Answer` bit(1) NOT NULL,
  `CreationDate` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ResponseRefer_idx` (`Refers`),
  KEY `ResponseSender_idx` (`Sender`),
  KEY `ResponseRec_idx` (`Receiver`),
  KEY `ResponseAbout_idx` (`About`),
  CONSTRAINT `ResponseAbout` FOREIGN KEY (`About`) REFERENCES `Event` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ResponseRec` FOREIGN KEY (`Receiver`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ResponseRefer` FOREIGN KEY (`Refers`) REFERENCES `InviteNotification` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ResponseSender` FOREIGN KEY (`Sender`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResponseNotification`
--

LOCK TABLES `ResponseNotification` WRITE;
/*!40000 ALTER TABLE `ResponseNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `ResponseNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserTable`
--

DROP TABLE IF EXISTS `UserTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserTable` (
  `Email` varchar(50) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Surname` varchar(30) NOT NULL,
  `ProfilePhoto` varchar(255) DEFAULT 'avatars/default.jpg',
  `PhoneNumber` int(11) NOT NULL,
  `Clearance` varchar(10) NOT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserTable`
--

LOCK TABLES `UserTable` WRITE;
/*!40000 ALTER TABLE `UserTable` DISABLE KEYS */;
INSERT INTO `UserTable` VALUES ('admin@gmail.com','admin','admin','avatars/default.jpg',9,'ADMIN','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8'),('first@yopmail.com','First','User ','http://s3.amazonaws.com/37assets/svn/765-default-avatar.png',0,'USER','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8');
/*!40000 ALTER TABLE `UserTable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WeatherNotification`
--

DROP TABLE IF EXISTS `WeatherNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WeatherNotification` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `State` varchar(45) DEFAULT 'UNREAD',
  `About` int(11) NOT NULL,
  `Receiver` varchar(50) NOT NULL,
  `SuggestedDate` datetime DEFAULT NULL,
  `CreationDate` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Rec_idx` (`Receiver`),
  KEY `Ev_idx` (`About`),
  CONSTRAINT `WeathEv` FOREIGN KEY (`About`) REFERENCES `Event` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `WeathRec` FOREIGN KEY (`Receiver`) REFERENCES `UserTable` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WeatherNotification`
--

LOCK TABLES `WeatherNotification` WRITE;
/*!40000 ALTER TABLE `WeatherNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `WeatherNotification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-01-25 23:34:03
